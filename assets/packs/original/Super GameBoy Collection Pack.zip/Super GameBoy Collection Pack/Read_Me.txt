Hi video game developer!

Thank you so much for downloading the Super GameBoy Collection pack!
-------------------------------------------------------------------------------------------------------
Copyright & Attribution Notice:

This asset pack has been released under the CC0 license. This means the assets contained within are public domain, and you can do the following with them:

You can remix, transform, or modify any and all assets to suit your needs.
You can use the assets for personal or commerical purposes.
You are not required to give attribution/credit to me - Niall Chandler - in the credits of your work or indeed at all (although you are more than welcome do as it would be greatly appreciated).
You cannot resell/redistribute this asset pack.

In short, you can basically do anything you want with this asset pack except try to sell it.
-------------------------------------------------------------------------------------------------------
Please leave a comment on the page you downloaded this pack from. If you have anything you feel you need to say, please let me know.
If you decide to use any of the assets in this pack in one of your games, you are welcome to show me as I'd love to see your game!

Additionally, if you need to contact me, my Twitter is @gingercakegames